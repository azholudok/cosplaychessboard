TEAM 1 (STAGE LEFT, ENTERS FIRST)
piece 1 = top rook
piece 2 = top knight
piece 3 = top bishop
piece 4 = QUEEN
piece 5 = KING (ENTERS LAST)
piece 6 = bottom bishop
piece 7 = bottom knight
piece 8 = bottom rook
piece 9 = pawn
piece 10 = pawn
piece 11 = pawn
piece 12 = pawn
piece 13 = pawn
piece 14 = pawn
piece 15 = pawn
piece 16 = pawn

TEAM 2 (STAGE RIGHT, ENTERS SECOND)
piece 17 = pawn
piece 18 = pawn
piece 19 = pawn
piece 20 = pawn
piece 21 = pawn
piece 22 = pawn
piece 23 = pawn
piece 24 = pawn
piece 25 = top rook
piece 26 = top knight
piece 27 = top bishop
piece 28 = QUEEN
piece 29 = KING (ENTERS LAST)
piece 30 = bottom bishop
piece 31 = bottom knight
piece 32 = bottom rook
